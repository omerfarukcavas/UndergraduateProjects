# CMPE250_2018Fall_Project1
CMPE250 2018Fall Project1

Due date: 24.10.2017 23:59

Please check out Project1.pdf for description of the project.

Due date is a strict due date!

How to compile
In a terminal, call commands:

>cmake CMakeLists.txt

>make

OR

>cmake CMakeLists.txt && make

Make sure the executable is produced.

Then you can test the project with the command:

>./project1 inputFile outputFile
